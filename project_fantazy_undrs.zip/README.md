# RunPod Serverless ComfyUI Endpoint

This repository runs ComfyUI headlessly inside a RunPod Serverless worker and executes workflows dynamically per request.

## Features

- Accepts input image as base64 or URL.
- Accepts workflow JSON per request.
- Supports both ComfyUI prompt format and graph workflow format.
- Auto-injects uploaded image into every `LoadImage` node.
- Runs ComfyUI in a persistent process so models stay loaded across requests.
- Returns the latest generated output image as base64.
- Structured error responses and timeout handling.

## Request Contract

```json
{
  "input": {
    "image": "<base64-or-http-url>",
    "workflow": { "...": "..." }
  }
}
```

## Success Response

```json
{
  "output": {
    "image": "<base64>"
  }
}
```

## Error Response

```json
{
  "error": "message"
}
```

## Files

- `Dockerfile`: Runtime image with ComfyUI and custom nodes.
- `handler.py`: RunPod serverless handler.
- `comfy_runner.py`: ComfyUI lifecycle, workflow conversion/injection, execution, polling.
- `utils/image_utils.py`: base64/URL decoding and output encoding.
- `workflow_template.json`: minimal runnable workflow example.
- `start.sh`: entrypoint script.
- `requirements.txt`: Python dependencies for the handler.

## Build

```bash
docker build -t runpod-comfy-serverless:latest .
```

### Build Args (Optional)

- `INSTALL_MODELS=1` (default): downloads public Qwen UNET/CLIP/VAE and Lightning LoRAs at image build time.
- `HF_TOKEN=<token>`: required for gated Hugging Face downloads like `simply-beauty-10`.
- `APP_PRIVATE_LORAS_DIR=models/loras` (default): relative path in build context to local private LoRA files.
- `LORA_REMOVE_CLOTHING_URL=<url>`: auto-download URL for `qwen_image_edit_remove-clothing_v1.0.safetensors` (defaults to a public Hugging Face source).
- `LORA_BEAUTY10_URL=<url>`: auto-download URL for `beuauty10.safetensors` (defaults to `miaaiart/simply-beauty-10`).
- `REQUIRE_PRIVATE_LORAS=1` (default): fail image build if required private LoRAs are still missing.
- `ALLOW_BEAUTY10_FALLBACK=1` (default): if beauty10 cannot be downloaded (for example gated 401/403), create `beuauty10.safetensors` from Lightning 8-step so requests do not fail due to missing file.

### Bundling Required Private LoRAs In The Image

For this workflow, these files are required and are now validated at image build time:

- `models/loras/qwen_image_edit_remove-clothing_v1.0.safetensors`
- `models/loras/beuauty10.safetensors`

Preferred approach:

1. Place the files in your repo under `models/loras/`.
2. Build the image normally.

Fallback approach:

1. Keep files out of the repo.
2. Build normally; Docker auto-downloads both LoRAs during image build.
3. For `simply-beauty-10`, pass a Hugging Face token if the repo gate requires access.
4. If beauty10 download is denied, Docker logs a clear access message and (by default) creates a fallback file to keep the endpoint runnable.

If the beauty10 repo gate has not been accepted and you disabled fallback, build fails early at image build time (not at request time).

Example:

```bash
docker build \
  --build-arg INSTALL_MODELS=1 \
  --build-arg HF_TOKEN=hf_xxx \
  -t runpod-comfy-serverless:latest .
```

## Runtime Notes

- Models are not downloaded during request handling.
- Ensure required models are baked into the image or mounted into ComfyUI models directories.
- ComfyUI custom nodes included here are based on your `requried models and nodes.txt` list.
- Runtime validates model files referenced by workflow loader nodes and returns explicit missing-model errors.

## Local Smoke Test Payload

Use your current workflow file `【NSFW】remove+clothes+in+image.json` as the request `input.workflow` value.
